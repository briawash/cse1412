x= input("Please enter a file name to be decrypted")  # Asking for the file to be decrypted
try:
    input_file = open( x,'r+')
except IOError.
    x= input("Please enter a file name to be decrypted")
file_key= open("EncryptionKey.TXT",'r')
decrytpted_file= s
y= input("Please enter output file name")#Asking for what they would like to be named the output file
new_file=

new_file= open(y,'r')
if IOError:
    
