# 1. open NBA data file
nba_file = open("player_regular_season.csv", "r")

def create_player_list(nba_file):
    """Create a list of players stats."""
    # Creates a list of added value
    player_list = []
    for line in nba_file:
        print(line)
        line_list = line.split(',')
        # create tuple: (minutes, last name, first name, year)
        player_tuple = (int(line_list[7]), line_list[3], line_list[2], line_list[1])
        mileage_list.append(player_tuple)        # 2bII. append tuple
    return player_list
    
def find_max_minutes_played(player_list, max_minutes):
    """Make a list of athletes with max playing timw list of player tuples"""
    max_minute_list = []
    
#find the max minutes

    for player_tuple in player_list:
        if player_tuple[0] == max_minutes:
            max_minute_list.append(player_tuple)      
    return max_minute_list

max_mileage = max(mileage_list)[0]

#4. create a list of all cars with max and min mileage: list of car tuples
max_mileage_list, min_mileage_list = \
                find_max_min_mileage(mileage_list,max_mileage,min_mileage)

print("Maximum Mileage Cars:")
for car_tuple in max_mileage_list:
    print("  ", car_tuple[1], car_tuple[2])
print("Minimum Mileage Cars: ")
for car_tuple in min_mileage_list:
    print("  ", car_tuple[1], car_tuple[2])
