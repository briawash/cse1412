encrypted= open("Encryption.txt, 'r')
key=[]
file= open("EncryptionKey.TXT,'r')
for line in file.readlines():
    for char in line:
        if(char!= '\n'):
            key.append.(char)
file.close
return key
key,file
output:""
alphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
for line in file.readlines():
             for char in line:
                 if (char.islower()):
                     output+= alpha[key.index(char)]
                elif (char.isupper()):
                    output+= alphabet[key.index(char.lower())].upper()
                else :
                   output+=char
file.close
print(output)
             

                                           
