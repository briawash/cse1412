x=9(input("please enter a number"))
if x==int(x):
    x==int(x)
    print(x)

