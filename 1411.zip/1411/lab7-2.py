import random
import string
qs_opts_file=open('QsandOpts.txt','r')
names_file=open('names.txt','r')
quizzes=[]
def qs_opts(file):
    for line in qs_opts_file: #question , options, answer
        line_list=line.split('\n')
        if line_list == ('1' or '2' or '3' or '4'):
            continue
        quizzes.append(line_list)
        qs_opts_tuple=()
        
    return quizzes
quizzes=qs_opts(qs_opts_file)
#for line in quizzes:
#replace_punctuation = string.maketrans(string.punctuation, ' '*len(string.punctuation))
#text = text.translate(replace_punctuation)
print(*quizzes, sep="\n")

names=[]
names_tuple=()
def names(file):
    for line in names_file:
        #line.strip()
        line_list=line.split('\n')
        names_tuple=line_list[0]
        names.append(names_tuple)
    return names
names=names(names_file)
print(names)
