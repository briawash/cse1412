str=input("Input a string: ")
target=input('input a character to find: ')
for index in range(len(str)):
    if str[index]==target:
        print ("Letter ", target, " found at index: " , index)
        break
else:
    print("Letter ", target, " not found in ", str)
