# 1. open NBA data file
nba_file = open("player_regular_season.csv", "r")

def create_player_list(nba_file):
    """Create a list of players stats."""
    # Creates a list of added value
    player_list=[]
    for line in nba_file:
        line_list = line.split(',')           # 2bI. csv => split on comma
        # create tuples
        player_tuple=(int(line_list[8])+ int(line_list[11])+ int(line_list[12])+ int(line_list[14])+ int(line_list[13])) -((line_list[17] - line_list[18])+(line_list[19]- line_list[20])+ line_list[15])/ line_list[6])
        player_list.append(player_tuple)
        return player_list
    count = 0
    while count<= 50:
        print(player_list)
        count+=1
                #for line in player_tuple.sort():
                  #  print(sorted_player_tuple, line_list[2], line_list[3])
        
player_list = create_player_list(nba_file)


