# 1. open NBA data file
nba_file = open("player_regular_season.csv", "r")
#create player list

def create_player_list(nba_file):
    """Create a list of players stats."""
    # Creates a list of added value
    player_list = []
    for line in nba_file:
        print(line)
        line_list = line.split(',')           # 2bI. csv => split on comma
        # create tuples
        if(len(line_list) > 15):
            player_tuple = ()
            if(line_list[0] != "ï»¿ilkid" and line_list[0] != "(21961 row(s) affected)"):# look for these errors
                if(line_list[15] == "NULL"):
                    line_list[15] = "0"
                if(line_list[14] == "NULL"):
                    line_list[14] = "0"
                if(line_list[13] == "NULL"):
                    line_list[13] = "0"
                if(line_list[0] == "ConleMi01 "):
                    player_tuple=(line_list[0], (int(line_list[9])+ int(line_list[12])+ int(line_list[13])+ int(line_list[15])+ int(line_list[14])) -((int(line_list[18]) - int(line_list[19]))+(int(line_list[20])- int(line_list[21]))+ int(line_list[16])/ int(line_list[7])))
                else:
                    player_tuple=(line_list[0], (int(line_list[8])+ int(line_list[11])+ int(line_list[12])+ int(line_list[14])+ int(line_list[13])) -((int(line_list[17]) - int(line_list[18]))+(int(line_list[19])- int(line_list[20]))+ int(line_list[15])/ int(line_list[6])))
                i = 0;
                while(i < len(player_list) and int(player_tuple[1]) < int(player_list[i][1]) and i < 50):
                    i = i + 1
                player_list.insert(i, player_tuple);
    return player_list #return the new calculated values


player_list = create_player_list(nba_file) #create the player list
count = 0
while count<= 50: #print top 50
    print(player_list[count])
    count += 1
               
