import random
import string

def readInQuestions(questionsFile, questions): #defining how to read in questions
    state = 0  #0:question, 1:answer choices, 2:correct answer
    question = []
    for line in questionsFile: #how to determine what line should be sorted where
        if state == 0:
            question.append(line) #adds it to the list  of answers
            state = 1 
        elif state == 1:
            answers = line.split("_") #splits up the answer choices
            question.append(answers)
            state = 2
        else:
            question.append(int(line))
            questions.append(question) #adds it to the question file
            question = []
            state = 0

def readInNames(namesFile, quizes): #reads in all the names
    for name in namesFile:
        quizes[name.rstrip()] = []

def assignQuestions(quizes, questions): #assigns questions to people
    keys = quizes.keys()
    for key in keys:
        for questionNumber in range(0, 5):
            randomNumber = random.randint(0, 25)
            quizes[key].append(questions[randomNumber])

def giveQuiz(currentQuiz): #actually give the quiz
    size = 5.0
    numberCorrect = 0.0
    questionNumber = 1
    for question in currentQuiz: # how to format the quiz and grade it
        print(str(questionNumber) + "." + question[0])
        questionNumber = questionNumber + 1
        answerNumber = 1
        for answerChoice in question[1]:
            print("\t" + str(answerNumber) + "." + answerChoice)
            answerNumber = answerNumber + 1
        answer = int(input(str("Answer :: "))) # how to grade 
        if answer == question[2]:
            numberCorrect = numberCorrect + 1
    return (numberCorrect/size)*100
#open files and creates  quiz and ask for users name
def main():
    questionsFile=open('QsandOpts.txt','r')
    namesFile=open('names.txt','r')
#create questions file
    questions=[]
    readInQuestions(questionsFile, questions)
#create the quizzes
    quizes = {}
    readInNames(namesFile, quizes)
    assignQuestions(quizes, questions)
 #ask for name and get quiz   
    name = input(str("Please enter your name :: "))
    currentQuiz = quizes.get(name, [])
#print out the quiz score
    score = giveQuiz(currentQuiz)
    print("Your Score Is :: " + str(score))
#close files
    questionsFile.close() 
    namesFile.close()

main()
